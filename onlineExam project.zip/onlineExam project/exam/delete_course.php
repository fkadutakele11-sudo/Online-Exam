<?php
include "db.php";
session_start();
$ins_id = $_SESSION['instructor_id'];

if(isset($_GET['id'])){
    $course_id = $_GET['id'];
    // ደህንነትን ለመጠበቅ፡ ኮርሱ የዚህ ኢንስትራክተር መሆኑን ቼክ ያደርጋል
    $conn->query("DELETE FROM courses WHERE id='$course_id' AND instructor_id='$ins_id'");
    header("Location: instructor.php"); // ወደ ዋናው ገጽ ይመለሳል
}
?>