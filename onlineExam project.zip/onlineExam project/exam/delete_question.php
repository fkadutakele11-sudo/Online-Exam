<?php
include "db.php";

$message = "";
$id = 0;

if(isset($_GET['id'])){
    $id = intval($_GET['id']);
}

if(isset($_POST['delete'])){

    $id = intval($_POST['id']);

    // SAME DATABASE LOGIC
    $sql = "DELETE FROM questions WHERE id=$id";
    $result = $conn->query($sql);

    if($result && $conn->affected_rows > 0){
        $message = "✅ Question deleted successfully!";
    }else{
        $message = "⚠ Question not found or could not be deleted!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Delete Question</title>

<style>

body{
font-family:Arial;
background:#f4f6f9;
display:flex;
justify-content:center;
align-items:center;
height:100vh;
margin:0;
}

.container{
background:white;
padding:30px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,0.2);
width:420px;
text-align:center;
}

button{
padding:10px 20px;
border:none;
border-radius:5px;
cursor:pointer;
margin:8px;
}

.delete{
background:#e74c3c;
color:white;
}

.cancel{
background:#3498db;
color:white;
}

.message{
font-weight:bold;
margin-bottom:15px;
color:green;
}

</style>

</head>

<body>

<div class="container">

<?php if($message!=""){ ?>

<p class="message"><?php echo $message; ?></p>

<a href="manage_questions.php">
<button class="cancel">Back</button>
</a>

<?php } else { ?>

<h3>Delete Question</h3>

<p>Do you want to delete Question ID <b><?php echo $id; ?></b> ?</p>

<form method="POST">

<input type="hidden" name="id" value="<?php echo $id; ?>">

<button type="submit" name="delete" class="delete">
Delete
</button>

</form>

<a href="manage_questions.php">
<button class="cancel">Cancel</button>
</a>

<?php } ?>

</div>

</body>
</html>