<?php
include "db.php";

/* GET USER ID */
if(!isset($_GET['id'])){
    header("Location: manage_users.php");
    exit();
}

$id = $_GET['id'];

/* FETCH USER DATA */
$data = $conn->query("SELECT * FROM users WHERE id='$id'");
$row = $data->fetch_assoc();

/* UPDATE USER */
if(isset($_POST['update'])){

    $name = $_POST['name'];
    $student_id = $_POST['student_id'];

    /* SAME DB LOGIC — only updating fields */
    $conn->query("
        UPDATE users 
        SET name='$name', student_id='$student_id'
        WHERE id='$id'
    ");

    /* SUCCESS MESSAGE */
    header("Location: manage_users.php?msg=User updated successfully");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit User</title>

<style>

body{
margin:0;
font-family:Arial, Helvetica, sans-serif;
background:#f4f6f9;
display:flex;
justify-content:center;
align-items:center;
height:100vh;
}

.card{
background:white;
padding:35px;
border-radius:10px;
box-shadow:0 8px 20px rgba(0,0,0,0.15);
width:380px;
text-align:center;
}

h2{
color:#2980b9;
margin-bottom:20px;
}

label{
display:block;
text-align:left;
margin-top:10px;
font-weight:bold;
}

input{
width:100%;
padding:10px;
margin-top:5px;
border:1px solid #ccc;
border-radius:5px;
}

button{
padding:10px 18px;
border:none;
border-radius:5px;
cursor:pointer;
color:white;
margin-top:15px;
}

.update{
background:#27ae60;
}

.update:hover{
background:#1e8449;
}

.back{
background:#7f8c8d;
margin-top:10px;
}

.back:hover{
background:#626567;
}

</style>
</head>

<body>

<div class="card">

<h2>Edit User</h2>

<form method="POST">

<label>Full Name</label>
<input type="text" name="name"
value="<?php echo $row['name']; ?>" required>

<label>Student ID</label>
<input type="text" name="student_id"
value="<?php echo $row['student_id']; ?>">

<button class="update" name="update">Update User</button>

</form>

<br>

<a href="manage_users.php">
<button class="back">Back</button>
</a>

</div>

</body>
</html>