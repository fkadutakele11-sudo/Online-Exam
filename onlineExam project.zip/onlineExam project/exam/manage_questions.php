<?php 
include "db.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Questions | Instructor Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #1e293b;
            --accent: #3b82f6;
            --success: #10b981;
            --danger: #ef4444;
            --bg: #f8fafc;
            --white: #ffffff;
        }

        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background: var(--bg);
            color: #334155;
            display: flex;
            justify-content: center;
            padding: 40px 20px;
        }

        .container {
            width: 100%;
            max-width: 1100px;
            animation: fadeIn 0.4s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .card {
            background: var(--white);
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.05);
            border: 1px solid #e2e8f0;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #f1f5f9;
            padding-bottom: 20px;
        }

        h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 700;
            color: var(--primary);
        }

        /* Action Buttons */
        .btn-group {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 10px 18px;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-back { background: #f1f5f9; color: #475569; }
        .btn-edit { background: var(--success); color: white; }
        .btn-delete { background: var(--danger); color: white; }

        .btn:hover {
            transform: translateY(-2px);
            filter: brightness(0.95);
        }

        /* Table Style */
        .table-wrapper {
            overflow-x: auto;
        }

        .prof-table {
            width: 100%;
            border-collapse: collapse;
            cursor: pointer;
        }

        .prof-table th {
            text-align: left;
            padding: 15px;
            background: #f8fafc;
            color: #64748b;
            font-weight: 600;
            font-size: 13px;
            text-transform: uppercase;
            border-bottom: 1px solid #e2e8f0;
        }

        .prof-table td {
            padding: 16px 15px;
            border-bottom: 1px solid #f1f5f9;
            font-size: 14px;
        }

        .prof-table tr:hover td {
            background: #fdfdfd;
        }

        /* Row Selection */
        .selected td {
            background: #f0f7ff !important;
            color: var(--accent) !important;
        }
        
        .selected {
            outline: 2px solid var(--accent);
            outline-offset: -2px;
        }

        .id-badge {
            background: #e2e8f0;
            padding: 4px 8px;
            border-radius: 6px;
            font-family: monospace;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="card">
        <div class="header-section">
            <h2>Manage Questions</h2>
            <div class="btn-group">
                <button class="btn btn-back" onclick="goBack()">⬅ Go Back</button>
                <button class="btn btn-edit" onclick="editQuestion()">✎ Edit</button>
                <button class="btn btn-delete" onclick="deleteQuestion()">🗑 Delete</button>
            </div>
        </div>

        <div class="table-wrapper">
            <table class="prof-table" id="questionsTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Question Description</th>
                        <th>Option A</th>
                        <th>Option B</th>
                        <th>Option C</th>
                        <th>Option D</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $q = $conn->query("SELECT * FROM questions");
                    while($row = $q->fetch_assoc()){
                    ?>
                    <tr data-id="<?php echo $row['id']; ?>">
                        <td><span class="id-badge">#<?php echo $row['id']; ?></span></td>
                        <td style="font-weight: 500; min-width: 250px;"><?php echo $row['question']; ?></td>
                        <td><?php echo $row['A']; ?></td>
                        <td><?php echo $row['B']; ?></td>
                        <td><?php echo $row['C']; ?></td>
                        <td><?php echo $row['D']; ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function goBack(){
    window.location.href = "instructor.php";
}

let selectedRow = null;
const table = document.getElementById("questionsTable");
const rows = table.getElementsByTagName("tbody")[0].getElementsByTagName("tr");

Array.from(rows).forEach((row)=>{
    row.addEventListener("click", function(){
        if(selectedRow) selectedRow.classList.remove("selected");
        this.classList.add("selected");
        selectedRow = this;
    });
});

function getSelectedQuestionId(){
    if(selectedRow) return selectedRow.dataset.id;
    alert("⚠ Please select a question from the table first!");
    return null;
}

function editQuestion(){
    const id = getSelectedQuestionId();
    if(id){
        if(confirm("Edit question #" + id + "?")){
            window.location.href = "edit_question.php?id=" + id;
        }
    }
}

function deleteQuestion(){
    const id = getSelectedQuestionId();
    if(id){
        if(confirm("Are you sure you want to delete question #" + id + "?")){
            window.location.href = "delete_question.php?id=" + id;
        }
    }
}
</script>

</body>
</html>