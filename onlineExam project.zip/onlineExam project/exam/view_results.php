<?php
session_start();
include "db.php";

if (!isset($_SESSION['instructor_id']) && !isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

//  (Role Identification)
$is_instructor = isset($_SESSION['instructor_id']);
$logged_in_id = $is_instructor ? $_SESSION['instructor_id'] : $_SESSION['student_id'];

//  (Delete Logic) 
if ($is_instructor && isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM results WHERE id='$id'");
    header("Location: view_results.php?msg=deleted");
    exit();
}

// 3. (Update Logic) 
if ($is_instructor && isset($_POST['update_result'])) {
    $res_id = $_POST['result_id'];
    $new_score = $_POST['new_score'];
    $conn->query("UPDATE results SET score='$new_score' WHERE id='$res_id'");
    header("Location: view_results.php?msg=updated");
    exit();
}

// (r.student_id = $logged_in_id) 
$sql = "SELECT r.*, e.exam_type, s.name 
        FROM results r 
        JOIN exams e ON r.exam_id = e.id
        JOIN students s ON r.student_id = s.id";

if (!$is_instructor) {
    // see only me
    $sql .= " WHERE r.student_id = '$logged_in_id'";
}

$sql .= " ORDER BY r.submitted_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Results | Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2c3e50;
            --accent: #3498db;
            --success: #27ae60;
            --danger: #e74c3c;
            --warning: #f39c12;
            --bg: #f4f7f6;
        }
        body { margin: 0; font-family: 'Inter', sans-serif; background-color: var(--bg); color: #333; }
        .header { background: var(--primary); color: white; padding: 15px 50px; display: flex; justify-content: space-between; align-items: center; }
        .container { max-width: 1150px; margin: 40px auto; padding: 0 20px; }
        .card { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); }
        h2 { color: var(--primary); border-bottom: 2px solid #eee; padding-bottom: 15px; margin-top: 0; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th { background-color: #f8f9fa; text-align: left; padding: 15px; font-size: 13px; color: #7f8c8d; border-bottom: 2px solid #eee; }
        td { padding: 15px; border-bottom: 1px solid #f0f0f0; }
        .badge { padding: 5px 12px; border-radius: 20px; font-size: 13px; font-weight: bold; }
        .pass { background-color: #e8f5e9; color: var(--success); }
        .fail { background-color: #ffebee; color: var(--danger); }
        .btn { padding: 6px 12px; border-radius: 6px; text-decoration: none; font-size: 12px; font-weight: 600; color: white; cursor: pointer; border: none; }
        .btn-edit { background: var(--warning); margin-right: 5px; }
        .btn-delete { background: var(--danger); }
        .btn-update { background: var(--success); }
        .edit-input { width: 60px; padding: 5px; border: 1px solid #ccc; border-radius: 4px; }
        .msg { padding: 10px; background: #d4edda; color: #155724; border-radius: 8px; margin-bottom: 20px; text-align: center; }
    </style>
</head>
<body>

<div class="header">
    <h2 style="margin:0; font-size: 20px; color:white;">
        <?php echo $is_instructor ? "Instructor Portal" : "Student Portal"; ?>
    </h2>
    <a href="<?php echo $is_instructor ? 'instructor.php' : 'student.php'; ?>" style="color:white; text-decoration:none; font-weight:600;">Dashboard</a>
</div>

<div class="container">
    <?php if(isset($_GET['msg'])): ?>
        <div class="msg">
            <?php echo ($_GET['msg'] == 'deleted') ? "Result deleted!" : "Result updated!"; ?>
        </div>
    <?php endif; ?>

    <div class="card">
        <h2><?php echo $is_instructor ? "All Student Records" : "My Performance Record"; ?></h2>

        <table>
            <thead>
                <tr>
                    <th>Ref ID</th>
                    <th>Student Name</th>
                    <th>Exam Type</th>
                    <th>Score</th>
                    <th>Percentage</th>
                    <?php if($is_instructor): ?> <th>Actions</th> <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php
                if($result && $result->num_rows > 0){
                    while($row = $result->fetch_assoc()){
                        $score = $row['score'];
                        $total = $row['total'];
                        $percentage = ($total > 0) ? round(($score/$total)*100, 2) : 0;
                        $class = ($percentage >= 50) ? "pass" : "fail";

                        echo "<tr>";
                        echo "<td>#".$row['id']."</td>";
                        echo "<td><strong>".$row['name']."</strong></td>";
                        echo "<td>".$row['exam_type']."</td>";
                        
                        // ለአስተማሪው ብቻ የ Edit ፎርም ያሳያል
                        if($is_instructor && isset($_GET['edit']) && $_GET['edit'] == $row['id']){
                            echo "<td>
                                    <form method='POST' style='display:flex; gap:5px;'>
                                        <input type='hidden' name='result_id' value='".$row['id']."'>
                                        <input type='number' name='new_score' class='edit-input' value='$score' required> / $total
                                  </td>";
                            echo "<td>-</td>";
                            echo "<td>
                                    <button type='submit' name='update_result' class='btn btn-update'>Save</button>
                                    <a href='view_results.php' class='btn btn-delete'>Cancel</a>
                                    </form>
                                  </td>";
                        } else {
                            echo "<td>".$score." / ".$total."</td>";
                            echo "<td><span class='badge $class'>".$percentage."%</span></td>";
                            
                            // ድርጊቶች ለአስተማሪው ብቻ
                            if($is_instructor){
                                echo "<td>
                                        <a href='view_results.php?edit=".$row['id']."' class='btn btn-edit'>Edit</a>
                                        <a href='view_results.php?delete=".$row['id']."' class='btn btn-delete' onclick='return confirm(\"Delete this result?\")'>Delete</a>
                                      </td>";
                            }
                        }
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' style='text-align:center; padding:30px; color:#95a5a6;'>No results found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>