<?php
include "db.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instructor Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --sidebar-bg: rgba(44, 62, 80, 0.95);
            --sidebar-hover: #3498db;
            --accent: #3498db;
            --primary: #2c3e50;
            --card-shadow: 0 15px 35px rgba(0,0,0,0.1);
        }

        body {
            margin: 0;
            font-family: 'Plus Jakarta Sans', sans-serif;
            /* Your background image remains the hero here */
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.7)), url('Web1.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            height: 100vh;
            color: white;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        .sidebar {
            width: 260px;
            background: var(--sidebar-bg);
            backdrop-filter: blur(10px);
            height: 100vh;
            position: fixed;
            color: white;
            display: flex;
            flex-direction: column;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-header h2 {
            margin: 0;
            font-size: 22px;
            color: var(--accent);
            text-transform: uppercase;
        }

        .nav-links {
            padding: 20px 0;
            flex-grow: 1;
        }

        .nav-links a {
            color: rgba(255,255,255,0.8);
            padding: 12px 25px;
            text-decoration: none;
            display: flex;
            align-items: center;
            font-size: 15px;
            transition: 0.3s;
            margin: 4px 15px;
            border-radius: 8px;
            cursor: pointer;
        }

        .nav-links a:hover {
            background: var(--sidebar-hover);
            color: white;
            transform: translateX(5px);
        }

        .main-content {
            margin-left: 260px;
            padding: 40px;
            width: calc(100% - 260px);
        }

        .welcome-section {
            background: GREEN;
            padding: 30px;
            border-radius: 15px;
            box-shadow: var(--card-shadow);
            border-left: 5px solid var(--accent);
            margin-bottom: 30px;
        }

        .card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: var(--card-shadow);
            max-width: 500px;
            animation: fadeIn 0.4s ease;
        }

        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }

        button, .button-link {
            display: inline-block;
            width: 100%;
            padding: 12px;
            background: var(--accent);
            color: white;
            text-decoration: none;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            text-align: center;
            margin-top: 15px;
            box-sizing: border-box;
        }

        select, input {
            width: 100%;
            padding: 10px;
            margin: 10px 0 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
    </style>
</head>

<body>

<div class="sidebar">
    <div class="sidebar-header">
        <h2> INSTRUCTOR PORTAL</h2>
        <small>Instructor Control</small>
    </div>
    
    <div class="nav-links">
        <a onclick="loadContent('dashboard')">🏠 Dashboard</a>
        <a onclick="loadContent('add_course')">📚 Add Course</a>
        <a onclick="loadContent('create_exam')">📝 Create Exam</a>
        <a onclick="loadContent('add_question')">➕ Add Questions</a>
        <a onclick="loadContent('manage_questions')">⚙️ Manage Questions</a>
        <a onclick="loadContent('view_results')">🏆 View Student Results</a>
        <a href="logout.php" style="background:#e74c3c; margin-top:20px; color:white; justify-content:center;">🚪 Logout</a>
    </div>
</div>

<div class="main-content" id="mainContent">
    <div class="welcome-section">
        <h2>Welcome, Instructor!</h2>
        <p>Use the sidebar to manage academic activities. You can create courses, set exams, and monitor student progress.</p>
    </div>
    
    <div style="display:flex; gap:20px;">
        <div class="card" style="max-width:200px; text-align:center;">
            <h2 style="color:BLACK; margin:0;">Courses</h2>
            <p>Manage all subjects</p>
        </div>
        <div class="card" style="max-width:200px; text-align:center;">
            <h2 style="color:#27ae60; margin:0;">Results</h2>
            <p>Track performance</p>
        </div>
    </div>
</div>

<script>
function loadContent(page){
    const content = document.getElementById('mainContent');
    
    if(page === 'dashboard'){
        content.innerHTML = `
            <div class="welcome-section">
                <h2>Portal Overview</h2> <p>Welcome to the Instructor Control Center. Use the sidebar to manage your academic tasks.</p>
            </div>
            <div style="display:flex; gap:20px; flex-wrap:wrap;">
                <div class="card" style="max-width:220px; text-align:center; padding:20px;">
                    <h3 style="color:#3498db; margin:0;">Courses</h3>
                    <p style="font-size:14px; color:#666;">Manage your subjects</p>
                </div>
                <div class="card" style="max-width:220px; text-align:center; padding:20px;">
                    <h3 style="color:#27ae60; margin:0;">Results</h3>
                    <p style="font-size:14px; color:#666;">View student scores</p>
                </div>
            </div>`;
    } 
    else if(page === 'add_course'){
        content.innerHTML = `
        <div class="card">
            <h3>Add New Course</h3>
            <p>Click the button below to go to the course creation page.</p>
            <a href="add_course.php" class="button-link">➕ Add New Course</a>
        </div>`;
    } 
    else if(page === 'view_results'){
        content.innerHTML = `
        <div class="card">
            <h3>Student Performance</h3>
            <p>Access the grading system to view and analyze student exam results.</p>
            <a href="view_results.php" class="button-link">Open Results Database</a>
        </div>`;
    } 
    else if(page === 'create_exam'){
        content.innerHTML = `<div class="card"><h3>Exam Configuration</h3><a href="create_exam.php" class="button-link">Go to Exam Creator</a></div>`;
    } 
    else if(page === 'add_question'){
        content.innerHTML = `<div class="card"><h3>Question Bank</h3><a href="add_question.php" class="button-link">Add New Questions</a></div>`;
    } 
    else if(page === 'manage_questions'){
        content.innerHTML = `<div class="card"><h3>Content Management</h3><a href="manage_questions.php" class="button-link">Edit Questions</a></div>`;
    }
}
</script>

</body>
</html>