<?php
//(Cache)
header("Cache-Control: no-cache, no-store, must-revalidate"); 
header("Pragma: no-cache"); 
header("Expires: 0"); 

session_start();
include "db.php";

$error = "";
if (isset($_SESSION['error_msg'])) {
    $error = $_SESSION['error_msg'];
    unset($_SESSION['error_msg']);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = trim($_POST['u_ident'] ?? ''); 
    $password = trim($_POST['p_secure'] ?? '');

    if ($user_id == "" || $password == "") {
        $_SESSION['error_msg'] = "All fields are required.";
        header("Location: login.php");
        exit();
    } else {
        // --- የሎጊን ሎጂክ ---
        $s = $conn->query("SELECT * FROM students WHERE student_id='$user_id'");
        if ($s->num_rows > 0) {
            $row = $s->fetch_assoc();
            $u = $conn->query("SELECT * FROM users WHERE student_id='$user_id' AND password='$password' AND role='student'");
            if($u->num_rows > 0){
                $_SESSION['student_id'] = $row['id']; 
                header("Location: student.php");
                exit();
            } else {
                $_SESSION['error_msg'] = "Invalid Student Credentials.";
                header("Location: login.php");
                exit();
            }
        } else {
            $sql = "SELECT * FROM users WHERE (student_id='$user_id' OR instructor_id='$user_id' OR name='$user_id') AND password='$password'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                if ($row['role'] == "admin") {
                    $_SESSION['admin_name'] = $row['name'];
                    header("Location: admin.php");
                    exit();
                } elseif ($row['role'] == "instructor") {
                    $_SESSION['instructor_id'] = $row['instructor_id'];
                    header("Location: instructor.php");
                    exit();
                } elseif ($row['role'] == "student") {
                    // አዲስ ተማሪ ከሆነ ዳታቤዝ ላይ ይመዘገባል
                    $stmt = $conn->prepare("INSERT INTO students (student_id, name, department_id) VALUES (?, ?, ?)");
                    $dept_id = $row['department_id']; 
                    $stmt->bind_param("ssi", $user_id, $row['name'], $dept_id);
                    if ($stmt->execute()) {
                        $_SESSION['student_id'] = $conn->insert_id; 
                        header("Location: student.php");
                        exit();
                    } else {
                        $_SESSION['error_msg'] = "Failed to create student record.";
                        header("Location: login.php");
                        exit();
                    }
                    $stmt->close();
                }
            } else {
                $_SESSION['error_msg'] = "Invalid ID or Password.";
                header("Location: login.php");
                exit();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>University Portal | Secure Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --bg-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --glass: rgba(255, 255, 255, 0.95);
            --text-dark: #1f2937;
            --text-light: #6b7280;
        }

        body {
            margin: 0;
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--bg-gradient);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
        }

        .login-box {
            background: var(--glass);
            padding: 40px;
            width: 100%;
            max-width: 400px;
            border-radius: 28px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            backdrop-filter: blur(10px);
            position: relative;
        }

        .logo-area { text-align: center; margin-bottom: 25px; }
        .logo-area i { font-size: 35px; color: var(--primary); background: #eef2ff; padding: 18px; border-radius: 18px; margin-bottom: 15px; }
        .login-box h2 { margin: 0; font-size: 26px; font-weight: 700; color: var(--text-dark); }

        .error {
            background: #fff1f2;
            color: #e11d48;
            padding: 12px;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 600;
            border-left: 4px solid #e11d48;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .input-group { margin-bottom: 20px; position: relative; }
        label { display: block; font-weight: 600; font-size: 13px; margin-bottom: 8px; color: var(--text-dark); }
        
        .input-wrapper { position: relative; }
        .input-wrapper i.left-icon { position: absolute; left: 16px; top: 50%; transform: translateY(-50%); color: var(--text-light); font-size: 16px; }
        
        .toggle-password { position: absolute; right: 16px; top: 50%; transform: translateY(-50%); cursor: pointer; color: var(--text-light); transition: 0.2s; }
        .toggle-password:hover { color: var(--primary); }

        input {
            width: 100%;
            padding: 14px 45px 14px 45px;
            border: 1px solid #e5e7eb;
            border-radius: 14px;
            font-size: 15px;
            background: #f9fafb;
            box-sizing: border-box;
            transition: all 0.3s ease;
        }

        input:focus { outline: none; background: #fff; border-color: var(--primary); box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1); }

        button {
            width: 100%;
            padding: 16px;
            background: var(--primary);
            color: white;
            border: none;
            font-size: 16px;
            font-weight: 700;
            border-radius: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 5px;
        }

        button:hover { background: var(--primary-hover); transform: translateY(-2px); }

        .forgot-password-area {
            text-align: center;
            margin-top: 25px;
            border-top: 1px solid #f3f4f6;
            padding-top: 15px;
        }

        .email-display {
            display: block;
            margin-top: 10px;
            font-size: 12px;
            color: #6b7280;
            word-break: break-all;
        }
        
        .email-box {
            background: #f3f4f6;
            padding: 4px 8px;
            border-radius: 6px;
            font-family: monospace;
            color: #1f2937;
            font-weight: 600;
        }
    </style>
</head>
<body onload="clearForm()">

<div class="login-box">
    <div class="logo-area">
        <i class="fas fa-university"></i>
        <h2>Welcome Back</h2>
    </div>

    <?php if($error != ""): ?>
        <div class="error">
            <i class="fas fa-circle-exclamation"></i>
            <?php echo $error; ?>
        </div>
    <?php endif; ?>

    <form action="login.php" method="POST" id="loginForm" autocomplete="off">
        <div class="input-group">
            <label>Identification Number</label>
            <div class="input-wrapper">
                <i class="fas fa-id-card left-icon"></i>
                <input type="text" name="u_ident" id="u_ident" placeholder="ID Number" required autocomplete="off">
            </div>
        </div>

        <div class="input-group">
            <label>Security Password</label>
            <div class="input-wrapper">
                <i class="fas fa-lock left-icon"></i>
                <input type="password" name="p_secure" id="passwordField" placeholder="••••••••" required autocomplete="new-password">
                <i class="fas fa-eye toggle-password" id="toggleIcon" onclick="togglePassword()"></i>
            </div>
        </div>

        <button type="submit">Sign In to Portal</button>

        <div class="forgot-password-area">
            <p style="color: #6b7280; font-size: 13px; margin-bottom: 8px;">Forgot your password?</p>
               <!-- get password -->
            <a href="mailto:fkadutakeleabera66827860@gmail.com?subject=Password%20Reset%20Request&body=Hello%20Admin,%0D%0A%0D%0AI%20forgot%20my%20portal%20password.%20Please%20help%20me%20reset%20it.%0D%0A%0D%0AMy%20ID:%20" 
               style="color: var(--primary); text-decoration: none; font-weight: 700; font-size: 14px; display: inline-flex; align-items: center; gap: 6px;">
               <i class="fas fa-envelope"></i> Contact Admin via Email
            </a>
        
            <div class="email-display">
                Or manually send to:<br>
                <span class="email-box">fkadutakeleabera66827860@gmail.com</span>
            </div>
        </div>
    </form>
</div>

<script>
    // ገጹ እንደተከፈተ ብሮውዘሩ የሞላውን መረጃ በግዳጅ ለማጥፋት
    function clearForm() {
        setTimeout(() => {
            const idField = document.getElementById('u_ident');
            const passField = document.getElementById('passwordField');
            if(idField) idField.value = '';
            if(passField) passField.value = '';
            document.getElementById('loginForm').reset();
        }, 15);
    }

    // ፓስዋርድን ለማሳየት እና ለመደበቅ
    function togglePassword() {
        const passwordField = document.getElementById('passwordField');
        const toggleIcon = document.getElementById('toggleIcon');
        
        if (passwordField.type === 'password') {
            passwordField.type = 'text';
            toggleIcon.classList.replace('fa-eye', 'fa-eye-slash');
        } else {
            passwordField.type = 'password';
            toggleIcon.classList.replace('fa-eye-slash', 'fa-eye');
        }
    }
</script>

</body>
</html>