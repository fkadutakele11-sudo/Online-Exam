<?php
include "db.php";

$selected_dept = isset($_POST['department_id']) ? $_POST['department_id'] : null;
$selected_course = isset($_POST['course_id']) ? $_POST['course_id'] : null;

// Determine which tab to show on page reload
$activeTab = ($selected_dept || $selected_course) ? "examTab" : ""; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard | Online Exam</title>
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #34495e;
            --accent: #3498db;
            --danger: #e74c3c;
            --success: #27ae60;
            --warning: #e67e22;
            --bg: #f4f7f6;
            --white: #ffffff;
        }

        body {
            margin: 0;
            font-family: 'Plus Jakarta Sans', sans-serif;
            /* Your background image remains the hero here */
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.7)), url('f21.webp');
            /* background-size: cover; */
            /* background-attachment: fixed; */
            /* background-position: center; */
            /* height: 10vh; */
            /* color: black; */
            /* overflow: hidden; */
            /* dsplay: flex; */
            /* flex-direction: column; */
        }


        /* Top Header */
        .header {
            background: var(--primary);
            color: white;
            padding: 15px 50px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header h2 { margin: 0; font-weight: 400; }

        .btn-logout {
            background: var(--danger);
            color: white;
            padding: 8px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-weight: bold;
        }

        /* Sub-Navigation */
        .subnav {
            background: var(--secondary);
            display: flex;
            justify-content: center;
        }

        .subnav button {
            background: none;
            border: none;
            color: rgba(255,255,255,0.7);
            padding: 15px 40px;
            cursor: pointer;
            font-size: 15px;
            font-weight: 600;
            transition: 0.3s;
            border-bottom: 3px solid transparent;
        }

        .subnav button:hover { color: white; background: rgba(167, 39, 252, 0.1); }

        .container {
            max-width: 850px;
            margin: 5px auto;
            padding: 0 20px;
        }

        .welcome-card {
            background:white;
            padding: 30px;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .tab-content {
            display: none;
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }

        .tab-content h3 { margin-top: 0; color: var(--primary); }

        label { display: block; margin: 15px 0 5px; font-weight: 600; font-size: 14px; }
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 15px;
            margin-bottom: 10px;
        }

        /* BUTTON & SPINNER CSS */
        .btn-submit {
            background: var(--accent);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
            font-weight: bold;
            margin-top: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            transition: 0.3s;
        }

        .btn-submit:disabled { background: #95a5a6; cursor: not-allowed; }

        .spinner {
            width: 18px;
            height: 18px;
            border: 3px solid rgba(255,255,255,0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
            display: none; /* Hidden by default */
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .action-group { display: flex; gap: 20px; justify-content: center; margin-top: 20px; }
        .btn-action {
            padding: 12px 25px;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: 0.3s;
        }

        .exam-card {
            background: #f9f9f9;
            padding: 20px;
            margin-top: 20px;
            border-left: 5px solid var(--accent);
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 5px;
        }

        .start-btn {
            background: var(--primary);
            color: white;
            padding: 8px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }
    </style>
</head>
<body onload="showTab('<?php echo $activeTab; ?>')">

<div class="header">
    <h2>Student Portal</h2>
    <a href="index.php" class="btn-logout">Logout</a>
</div>

<div class="subnav">
    <button onclick="showTab('actionTab')">Quick Actions</button>
    <button onclick="showTab('examTab')">Take Exam</button>
</div>

<div class="container">
    <div class="welcome-card">
        <h1 style=color:green>Welcome Back!</h1>
        <p>Manage your profile or start an exam using the navigation above.</p>
    </div>

    <div id="actionTab" class="tab-content">
        <h3>User Profile & Results</h3>
        <div class="action-group">
            <a href="view_profile.php" class="btn-action" style="background:var(--success);">View Profile</a>
            <a href="view_results.php" class="btn-action" style="background:var(--warning);">View Results</a>
        </div>
    </div>

    <div id="examTab" class="tab-content">
        <h3>Find Available Exams</h3>
        <form method="POST" onsubmit="startLoading()">
            <label>Select Department</label>
            <select name="department_id" id="deptSelect" required>
                <option value="">-- Choose Department --</option>
                <?php
                $departments = $conn->query("SELECT * FROM departments");
                while($d = $departments->fetch_assoc()){
                    $selected = ($selected_dept == $d['id']) ? "selected" : "";
                    echo "<option value='".$d['id']."' $selected>".$d['dept_name']."</option>";
                }
                ?>
            </select>

            <label>Select Course</label>
            <select name="course_id" id="courseSelect" required>
                <option value="">-- Choose Course --</option>
            </select>

            <button type="submit" id="submitBtn" class="btn-submit">
                <span id="btnText">Show Available Exams</span>
                <div id="btnSpinner" class="spinner"></div>
            </button>
        </form>

        <?php
        if($selected_dept && $selected_course){
            echo "<hr style='margin-top:30px; border:0; border-top:1px solid #eee;'>";
            $result = $conn->query("SELECT * FROM exams WHERE course_id='$selected_course'");
            if($result->num_rows > 0){
                while($row = $result->fetch_assoc()){
                    echo "<div class='exam-card'>";
                    echo "<div><strong>Exam Type:</strong> ".$row['exam_type']."</div>";
                    echo "<a class='start-btn' href='take_exam.php?exam=".$row['id']."'>Start Now</a>";
                    echo "</div>";
                }
            } else {
                echo "<p style='text-align:center; color:gray; margin-top:20px;'>No exams available for this course.</p>";
            }
        }
        ?>
    </div>
</div>

<script>
    // TRIGGER LOADING STATE
    function startLoading() {
        const btn = document.getElementById('submitBtn');
        const text = document.getElementById('btnText');
        const spinner = document.getElementById('btnSpinner');

        btn.disabled = true; // Prevent double clicking
        text.innerText = "Searching...";
        spinner.style.display = "block";
    }

    function showTab(tabId) {
        if(!tabId) return;
        document.querySelectorAll('.tab-content').forEach(tab => tab.style.display = 'none');
        document.getElementById(tabId).style.display = 'block';
    }

    /* Course Logic */
    const courses = <?php
        $all_courses = [];
        $c_result = $conn->query("SELECT * FROM courses");
        while($c = $c_result->fetch_assoc()){ $all_courses[] = $c; }
        echo json_encode($all_courses);
    ?>;

    const deptSelect = document.getElementById("deptSelect");
    const courseSelect = document.getElementById("courseSelect");
    const selectedCourse = <?php echo json_encode($selected_course); ?>;

    function populateCourses(deptId){
        courseSelect.innerHTML = '<option value="">-- Choose Course --</option>';
        courses.forEach(function(c){
            if(c.department_id == deptId){
                let opt = document.createElement("option");
                opt.value = c.id;
                opt.textContent = c.course_name;
                if(c.id == selectedCourse){ opt.selected = true; }
                courseSelect.appendChild(opt);
            }
        });
    }

    deptSelect.addEventListener("change", function(){
        populateCourses(this.value);
    });

    <?php if($selected_dept){ ?>
        populateCourses(<?php echo $selected_dept; ?>);
    <?php } ?>
</script>

</body>
</html>