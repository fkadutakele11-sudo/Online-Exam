<?php
include "db.php";
session_start();

// Ensure student is logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

// Fetch student info with department - KEEPING YOUR EXACT LOGIC
$stmt = $conn->prepare("
    SELECT s.name, s.student_id, d.dept_name
    FROM students s
    LEFT JOIN departments d ON s.department_id = d.id
    WHERE s.id = ?
");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();

// Safe fallback values
$student_name = $student['name'] ?? 'N/A';
$student_student_id = $student['student_id'] ?? 'N/A';
$student_department = $student['dept_name'] ?? 'N/A';

$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Profile | Student Portal</title>
    <style>
        :root {
            --primary: #2c3e50;
            --accent: #3498db;
            --bg: #f4f7f6;
            --white: #ffffff;
            --text-muted: #7f8c8d;
        }

        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--bg); 
            margin: 0;
            color: #333;
        }

        .header {
            background: var(--primary);
            color: white;
            padding: 15px 50px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .container {
            max-width: 550px;
            margin: 60px auto;
            padding: 0 20px;
        }

        .profile-card { 
            background: var(--white); 
            border-radius: 15px; 
            box-shadow: 0 15px 35px rgba(0,0,0,0.1); 
            overflow: hidden;
        }

        .profile-banner {
            background: var(--accent);
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .profile-banner h2 { 
            color: white; 
            margin: 0; 
            font-weight: 500;
            letter-spacing: 1px;
        }

        .profile-content {
            padding: 40px;
        }

        .profile-row { 
            display: flex;
            justify-content: space-between;
            padding: 15px 0;
            border-bottom: 1px solid #f0f0f0;
            font-size: 16px; 
        }

        .profile-row:last-of-type {
            border-bottom: none;
            margin-bottom: 20px;
        }

        .label { 
            font-weight: 600; 
            color: var(--text-muted); 
            text-transform: uppercase;
            font-size: 13px;
            letter-spacing: 0.5px;
        }

        .value {
            font-weight: 500;
            color: var(--primary);
        }

        .back-btn { 
            display: block; 
            text-align: center;
            padding: 12px; 
            background: var(--primary); 
            color: white; 
            text-decoration: none; 
            border-radius: 8px; 
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .back-btn:hover { 
            background: #1a252f;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .avatar-circle {
            width: 80px;
            height: 80px;
            background: #eee;
            border: 4px solid white;
            border-radius: 50%;
            margin: -40px auto 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
            color: var(--accent);
            position: relative;
            z-index: 2;
        }
    </style>
</head>
<body>

<div class="header">
    <h2 style="margin:0; font-size: 20px;">Student Portal</h2>
</div>

<div class="container">
    <div class="profile-card">
        <div class="profile-banner">
            <h2>ACCOUNT PROFILE</h2>
        </div>
        
        <div class="avatar-circle">
            👤
        </div>

        <div class="profile-content">
            <div class="profile-row">
                <span class="label">Full Name</span>
                <span class="value"><?php echo htmlspecialchars($student_name); ?></span>
            </div>
            
            <div class="profile-row">
                <span class="label">Identification No.</span>
                <span class="value"><?php echo htmlspecialchars($student_student_id); ?></span>
            </div>
            
            <a class="back-btn" href="student.php">Return to Dashboard</a>
        </div>
    </div>
</div>

</body>
</html>