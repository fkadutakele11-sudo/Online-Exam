<?php
include "db.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Course | DTU Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --bg: #f1f5f9;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --card-bg: #ffffff;
            --input-border: #cbd5e1;
            --success: #059669;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
        }

        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #e2e8f0 0%, #f8fafc 100%);
            color: var(--text-main);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }

        .page-wrapper {
            width: 100%;
            max-width: 440px;
            animation: slideUp 0.5s ease-out;
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            text-decoration: none;
            color: var(--text-muted);
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 24px;
            transition: all 0.2s;
            padding: 8px 12px;
            border-radius: 8px;
        }

        .back-link:hover {
            color: var(--primary);
            background: rgba(37, 99, 235, 0.05);
        }

        .card {
            background: var(--card-bg);
            padding: 40px;
            border-radius: 20px;
            box-shadow: var(--shadow-lg);
            border: 1px solid rgba(255, 255, 255, 0.8);
        }

        .header-section {
            text-align: center;
            margin-bottom: 32px;
        }

        h2 {
            margin: 0 0 8px 0;
            font-size: 28px;
            font-weight: 800;
            letter-spacing: -0.025em;
            color: var(--text-main);
        }

        .subtitle {
            color: var(--text-muted);
            font-size: 15px;
            margin: 0;
        }

        .form-group {
            margin-bottom: 24px;
        }

        label {
            display: block;
            font-size: 13px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 8px;
            color: var(--text-muted);
        }

        input, select {
            width: 100%;
            padding: 12px 16px;
            border-radius: 10px;
            border: 2px solid var(--input-border);
            box-sizing: border-box;
            font-family: inherit;
            font-size: 15px;
            color: var(--text-main);
            background-color: #f8fafc;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }

        input::placeholder {
            color: #94a3b8;
        }

        input:focus, select:focus {
            outline: none;
            border-color: var(--primary);
            background-color: #fff;
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.15);
        }

        button {
            width: 100%;
            padding: 14px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 700;
            font-size: 16px;
            box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.2);
            transition: all 0.2s;
            margin-top: 8px;
        }

        button:hover {
            background: var(--primary-hover);
            box-shadow: 0 10px 15px -3px rgba(37, 99, 235, 0.3);
            transform: translateY(-1px);
        }

        button:active {
            transform: translateY(0);
        }

        .message {
            background: #ecfdf5;
            color: var(--success);
            padding: 16px;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            text-align: center;
            margin-bottom: 24px;
            border: 1px solid #a7f3d0;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    </style>
</head>

<body>

<div class="page-wrapper">
    <a href="instructor.php" class="back-link">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 8px;"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
        Back to Dashboard
    </a>

    <div class="card">
        <div class="header-section">
            <h2>Add Course</h2>
            <p class="subtitle">Create a new academic subject</p>
        </div>

        <?php
        if(isset($_POST['course']) && isset($_POST['dept_id'])){
            $course = $_POST['course'];
            $dept = $_POST['dept_id'];

            // Logic preserved as requested
            $conn->query("INSERT INTO courses(course_name, department_id) VALUES('$course', '$dept')");

            echo "<div class='message'>
                    <svg width='20' height='20' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'><polyline points='20 6 9 17 4 12'></polyline></svg>
                    Course Added Successfully!
                  </div>";
        }
        ?>

        <form method="POST">
            <div class="form-group">
                <label for="dept_id">Department</label>
                <select id="dept_id" name="dept_id" required>
                    <option value="" disabled selected>Choose a department</option>
                    <?php
                    $result = $conn->query("SELECT * FROM departments");
                    while($row = $result->fetch_assoc()){
                        echo "<option value='".$row['id']."'>".$row['dept_name']."</option>";
                    }
                    ?>
                </select>
            </div>
             <div class="form-group">
                <label for="course">Course Name</label>
                <input type="text" id="course" name="course" placeholder="e.g. Introduction to PHP" required>
            </div>

            <button type="submit">Create Course</button>
        </form>
    </div>
</div>

</body>
</html>