<?php
include "db.php";

$successMsg="";
$errors=[
    "deptname"=>"",
    "role"=>"",
    "sid"=>"",
    "insid"=>"", 
    "name"=>"",
    "pass"=>"",
    "dept"=>""
];

$activeTab = ""; 

/* ================= ADD DEPARTMENT ================= */
if(isset($_POST['addDept'])){
    $activeTab = "deptTab"; 
    $dept = trim($_POST['dept'] ?? '');
    if(empty($dept)){
        $errors["deptname"]="Department name is required.";
    } elseif(!preg_match("/^[a-zA-Z\s]+$/",$dept)){
        $errors["deptname"]="Department name must contain letters only.";
    }else{
        $conn->query("INSERT INTO departments(dept_name) VALUES('$dept')");
        $successMsg="Department added successfully";
    }
}

/* ================= REGISTER USER ================= */
if(isset($_POST['registerUser'])){
    $activeTab = "registerTab"; 
    $role = $_POST['role'] ?? "";
    $name = trim($_POST['name'] ?? '');
    $pass = $_POST['pass'] ?? '';
    $dept = $_POST['dept'] ?? ""; 
    $sid  = trim($_POST['sid'] ?? '');
    $insid = trim($_POST['insid'] ?? ''); 

    $valid=true;

    if($role==""){
        $errors["role"]="Please select a role.";
        $valid=false;
    }

    if(empty($name)){
        $errors["name"]="Name is required.";
        $valid=false;
    } elseif(!preg_match("/^[a-zA-Z\s]+$/",$name)){
        $errors["name"]="Full name must contain letters only.";
        $valid=false;
    }

    if(strlen($pass)<4){
        $errors["pass"]="Password must be at least 4 characters.";
        $valid=false;
    }

    if($role=="student"){
        if($sid==""){
            $errors["sid"]="Student ID required.";
            $valid=false;
        } elseif(!preg_match("/^DTU[0-9]{2}R[0-9]{4}$/",$sid)){
            $errors["sid"]="Format must be like DTU16R6610.";
            $valid=false;
        }
        if($dept==""){
            $errors["dept"]="Please select a department for the student.";
            $valid=false;
        }
    }

    if($role=="instructor"){
        if(empty($insid)){
            $errors["insid"]="Instructor ID is required.";
            $valid=false;
        }
        if($dept==""){
            $errors["dept"]="Instructor must select department.";
            $valid=false;
        }
    }

    if($valid){
        if($role=="student"){
            $conn->query("INSERT INTO users(role,name,student_id,password,department_id) VALUES('student','$name','$sid','$pass','$dept')");
            $successMsg="Student created successfully";
        } elseif($role=="instructor"){
            // data can be insert into new 'instructor_id'.
            $conn->query("INSERT INTO users(role,name,instructor_id,password,department_id) VALUES('instructor','$name','$insid','$pass','$dept')");
            $successMsg="Instructor registered successfully";
        } elseif($role=="admin"){
            $conn->query("INSERT INTO users(role,name,password) VALUES('admin','$name','$pass')");
            $successMsg="Admin created successfully";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #34495e;
            --accent: #3498db;
            --danger: #e74c3c;
            --success: #27ae60;
            --bg: #f4f7f6;
        }

        body {
            margin: 0;
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.7)), url('Web1.jpg');
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg);
            color: #333;
        }

        .header {
            background: var(--primary);
            color: white;
            padding: 15px 50px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .btn-logout {
            background: var(--danger);
            color: white;
            padding: 8px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-weight: bold;
        }

        .subnav { background: var(--secondary); display: flex; justify-content: center; }

        .subnav button {
            background: none; border: none; color: rgba(255,255,255,0.7);
            padding: 15px 30px; cursor: pointer; font-size: 15px; transition: 0.3s;
        }

        .subnav button:hover { color: white; background: rgba(255,255,255,0.1); }

        .container { max-width: 850px; margin: 40px auto; padding: 0 20px; }

        .welcome-card {
            background: white; padding: 30px; border-radius: 8px;
            text-align: center; box-shadow: 0 4px 6px rgba(0,0,0,0.05); margin-bottom: 30px;
        }

        .card {
            background: white; padding: 40px; border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1); display: none;
        }

        h3 { margin-top: 0; color: var(--primary); }
        label { display: block; margin: 15px 0 5px; font-weight: 600; font-size: 14px; }
        
        input, select {
            width: 100%; padding: 12px; border: 1px solid #ddd;
            border-radius: 5px; box-sizing: border-box; font-size: 15px;
        }

        .btn-action {
            background: var(--accent); color: white; border: none;
            padding: 12px 25px; border-radius: 5px; cursor: pointer;
            width: 100%; font-size: 16px; margin-top: 20px; font-weight: bold;
        }

        .message {
            background: var(--success); color: white; padding: 15px;
            border-radius: 5px; text-align: center; margin-bottom: 20px;
        }

        .error-msg { color: var(--danger); font-size: 13px; margin-top: 4px; font-weight: bold; }
        .error-border { border: 2px solid var(--danger) !important; background: #fff8f8; }
        
        /* Initial state of wrappers */
        #insidWrapper, #sidWrapper, #deptWrapper { display: none; }
    </style>
    <script>
        function showTab(tabId){
            if(!tabId) return;
            document.querySelectorAll(".card").forEach(c => c.style.display = "none");
            document.getElementById(tabId).style.display = "block";
        }

        function roleChange(){
            let role = document.getElementById("role").value;
            let sidBox = document.getElementById("sidWrapper");
            let insidBox = document.getElementById("insidWrapper");
            let deptBox = document.getElementById("deptWrapper");

            // Reset visibility
            sidBox.style.display = "none";
            insidBox.style.display = "none";
            deptBox.style.display = "none";

            if(role === "student"){
                sidBox.style.display = "block";
                deptBox.style.display = "block";
            } else if(role === "instructor"){
                insidBox.style.display = "block";
                deptBox.style.display = "block";
            } else if(role === "admin") {
                deptBox.style.display = "none";
            }
        }
    </script>
</head>
<body onload="showTab('<?php echo $activeTab; ?>'); roleChange();">

<div class="header">
    <h2>Admin Dashboard</h2>
    <a href="logout.php" class="btn-logout">Logout</a>
</div>

<div class="subnav">
    <button onclick="showTab('deptTab')">Add Department</button>
    <button onclick="showTab('registerTab')">Register User</button>
    <button onclick="window.location='manage_users.php'">Manage Users</button>
</div>

<div class="container">
    <div class="welcome-card">
        <h1>Welcome, Administrator</h1>
        <p>Manage your university departments and user accounts securely.</p>
    </div>

    <?php if($successMsg): ?>
        <div class="message"><?php echo $successMsg; ?></div>
    <?php endif; ?>

    <div id="deptTab" class="card">
        <h3>Add New Department</h3>
        <form method="POST">
            <label>Department Name</label>
            <input type="text" name="dept" placeholder="Enter department name" 
                   class="<?php echo !empty($errors['deptname']) ? 'error-border' : ''; ?>"
                   value="<?php echo htmlspecialchars($_POST['dept'] ?? ''); ?>">
            <div class="error-msg"><?php echo $errors['deptname']; ?></div>
            <button name="addDept" class="btn-action">Save Department</button>
        </form>
    </div>

    <div id="registerTab" class="card">
        <h3>Register System User</h3>
        <form method="POST">
            <label>User Role</label>
            <select name="role" id="role" onchange="roleChange()" class="<?php echo !empty($errors['role']) ? 'error-border' : ''; ?>">
                <option value="">Select Role</option>
                <option value="admin" <?php echo (isset($_POST['role']) && $_POST['role']=='admin')?'selected':''; ?>>Admin</option>
                <option value="instructor" <?php echo (isset($_POST['role']) && $_POST['role']=='instructor')?'selected':''; ?>>Instructor</option>
                <option value="student" <?php echo (isset($_POST['role']) && $_POST['role']=='student')?'selected':''; ?>>Student</option>
            </select>
            <div class="error-msg"><?php echo $errors['role']; ?></div>

            <div id="sidWrapper">
                <label>Student ID</label>
                <input type="text" name="sid" placeholder="DTU16R6610" 
                       class="<?php echo !empty($errors['sid']) ? 'error-border' : ''; ?>"
                       value="<?php echo htmlspecialchars($_POST['sid'] ?? ''); ?>">
                <div class="error-msg"><?php echo $errors['sid']; ?></div>
            </div>

            <div id="insidWrapper">
                <label>Instructor ID</label>
                <input type="text" name="insid" placeholder="INS/102/16" 
                       class="<?php echo !empty($errors['insid']) ? 'error-border' : ''; ?>"
                       value="<?php echo htmlspecialchars($_POST['insid'] ?? ''); ?>">
                <div class="error-msg"><?php echo $errors['insid']; ?></div>
            </div>

            <label>Full Name</label>
            <input type="text" name="name" placeholder="Enter full name" 
                   class="<?php echo !empty($errors['name']) ? 'error-border' : ''; ?>"
                   value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
            <div class="error-msg"><?php echo $errors['name']; ?></div>

            <label>Password</label>
            <input type="password" name="pass" placeholder="Create password" 
                   class="<?php echo !empty($errors['pass']) ? 'error-border' : ''; ?>">
            <div class="error-msg"><?php echo $errors['pass']; ?></div>

            <div id="deptWrapper">
                <label>Department Assignment</label>
                <select name="dept" id="deptSelect" class="<?php echo !empty($errors['dept']) ? 'error-border' : ''; ?>">
                    <option value="">Choose Department</option>
                    <?php
                    $d=$conn->query("SELECT * FROM departments ORDER BY dept_name ASC");
                    while($row=$d->fetch_assoc()){
                        $sel = (isset($_POST['dept']) && $_POST['dept'] == $row['id']) ? 'selected' : '';
                        echo "<option value='".$row['id']."' $sel>".$row['dept_name']."</option>";
                    }
                    ?>
                </select>
                <div class="error-msg"><?php echo $errors['dept']; ?></div>
            </div>

            <button name="registerUser" class="btn-action">Register User</button>
        </form>
    </div>
</div>

</body>
</html>