<?php
session_start();
include "db.php";

if(!isset($_SESSION['student_id'])){
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['student_id'];
$exam = $_GET['exam'] ?? 0;

$check_result = $conn->query("SELECT * FROM results WHERE student_id='$student_id' AND exam_id='$exam'");
$already_taken = ($check_result->num_rows > 0);

$q = $conn->query("SELECT * FROM questions WHERE exam_id=$exam");
$questions = [];
while($row = $q->fetch_assoc()){
    $questions[] = $row;
}

$totalQuestions = count($questions);
$totalPages = ceil($totalQuestions / 2); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Assessment | Secure Mode</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
<style>
    :root {
        --primary-dark: #1e293b;
        --accent-blue: #3b82f6;
        --success-green: #10b981;
        --error-red: #ef4444;
        --glass-bg: rgba(255, 255, 255, 0.98);
        --text-main: #334155;
        --border-color: #e2e8f0;
    }

    body {
        margin: 0;
        font-family: 'Inter', sans-serif;
        background: #f1f5f9;
        color: var(--text-main);
        min-height: 100vh;
        user-select: none;
    }

    /* 🏗 Header & Timer Bar */
    .header-wrapper {
        position: sticky;
        top: 0;
        z-index: 1000;
        width: 100%;
    }

    .exam-header {
        background: var(--primary-dark);
        color: white;
        padding: 15px 5%;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

   /* ⏳ የቀይ መስመሩ ማቀፊያ (Container) */
.timer-progress-container {
    width: 100%;
    height: 25px; /* ስፋቱን እዚህ ጋር ጨምረነዋል */
    background: #cbd5e1;
    overflow: hidden;
    border-bottom: 3px solid rgba(0,0,0,0.1); /* ትንሽ ጥላ እንዲኖረው */
    box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);
}

/* 🔴 የሚቀንሰው ቀይ መስመር (The Bar itself) */
#timerBar {
    width: 100%;
    height: 100%;
    /* ይበልጥ እንዲጎላ Gradient እና Glow ተጨምሮበታል */
    background: linear-gradient(90deg, #ff4d4d, #ff0000); 
    transition: width 1s linear;
    box-shadow: 0 0 15px rgba(255, 0, 0, 0.7); 
    border-radius: 0 10px 10px 0;
}

    /* 🔘 Navigation Dots */
    .nav-dots {
        display: flex;
        justify-content: center;
        gap: 12px;
        margin: 25px 0;
    }

    .dot {
        width: 14px;
        height: 14px;
        border-radius: 50%;
        background: #cbd5e1;
        transition: all 0.3s ease;
        border: 2px solid transparent;
    }

    .dot.active {
        background: var(--accent-blue);
        transform: scale(1.4);
        border-color: white;
        box-shadow: 0 0 8px rgba(59, 130, 246, 0.5);
    }

    form, .error-container {
        max-width: 800px;
        margin: 20px auto 80px auto;
        background: var(--glass-bg);
        padding: 40px;
        border-radius: 20px;
        box-shadow: 0 15px 35px rgba(0,0,0,0.05);
        border: 1px solid white;
    }

    .question { margin-bottom: 30px; animation: fadeIn 0.5s ease; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

    .option-label {
        display: flex;
        align-items: center;
        padding: 14px 20px;
        margin-bottom: 12px;
        background: white;
        border: 2px solid var(--border-color);
        border-radius: 12px;
        cursor: pointer;
        transition: 0.2s;
    }

    .option-label:hover { border-color: var(--accent-blue); background: #f8faff; }
    .option-label:has(input:checked) { border-color: var(--accent-blue); background: #eff6ff; }

    input[type="radio"] { margin-right: 15px; transform: scale(1.2); }

    .nav-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 40px;
        padding-top: 25px;
        border-top: 2px solid #f1f5f9;
    }

    .nav-btn {
        padding: 12px 30px;
        border-radius: 10px;
        font-weight: 700;
        cursor: pointer;
        border: none;
        transition: 0.3s;
    }

    #prevBtn { background: #e2e8f0; color: var(--primary-dark); }
    #nextBtn { background: var(--primary-dark); color: white; }
    #submitBtn { background: var(--success-green); color: white; box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3); }

    #startOverlay {
        position: fixed;
        inset: 0;
        background: #0f172a;
        z-index: 9999;
        display: flex;
        justify-content: center;
        align-items: center;
        color: white;
        text-align: center;
    }

    #top-timer-text { font-family: 'Courier New', Courier, monospace; font-size: 1.2rem; }
</style>
</head>
<body>

<div class="header-wrapper">
    <div class="exam-header">
        <h2><i class="fas fa-user-shield"></i> Assessment Mode</h2>
        <div id="top-timer-text"><i class="far fa-clock"></i> --:--</div>
    </div>
    <div class="timer-progress-container">
        <div id="timerBar"></div>
    </div>
</div>

<?php if($already_taken): ?>
    <div class="error-container" style="text-align:center;">
        <i class="fas fa-check-circle fa-4x" style="color:var(--success-green)"></i>
        <h2>Exam Already Submitted</h2>
        <p>Your responses have been recorded. You cannot retake this exam.</p>
        <a href="student.php" class="nav-btn" style="text-decoration:none; display:inline-block; background:var(--accent-blue); color:white;">Go Dashboard</a>
    </div>
<?php else: ?>
    <div id="startOverlay">
        <div style="max-width:450px; padding:30px; background:rgba(255,255,255,0.05); border-radius:20px; border:1px solid rgba(255,255,255,0.1);">
            <i class="fas fa-lock fa-3x" style="margin-bottom:20px; color:var(--accent-blue)"></i>
            <h1>Ready to Begin?</h1>
            <p>The exam will launch in <b>Full Screen Mode</b>. Your progress will be monitored.</p>
            <button id="realStartBtn" style="padding:15px 40px; background:var(--accent-blue); color:white; border:none; border-radius:10px; font-weight:bold; cursor:pointer; font-size:1.1rem;">INITIALIZE EXAM</button>
        </div>
    </div>

    <form id="examForm" action="submit_exam.php" method="POST">
        <input type="hidden" name="exam_id" value="<?php echo $exam; ?>">
        <input type="hidden" name="student_id" value="<?php echo $_SESSION['student_id']; ?>">

        <div class="nav-dots" id="dotsContainer">
            <?php for($i=0; $i<$totalPages; $i++): ?>
                <div class="dot <?php echo ($i==0)?'active':''; ?>"></div>
            <?php endfor; ?>
        </div>

        <div id="questionsContainer">
        <?php foreach($questions as $index => $row): ?>
        <div class="question" data-index="<?php echo $index; ?>" style="display:none;">
            <h4 style="font-size:1.25rem;"><span style="color:var(--accent-blue); font-weight:800;">Q<?php echo ($index + 1); ?>.</span> <?php echo htmlspecialchars($row['question']); ?></h4>
            <?php foreach(['A','B','C','D'] as $opt): ?>
            <label class="option-label">
                <input type="radio" name="q<?php echo $row['id']; ?>" value="<?php echo $opt; ?>"> 
                <span><?php echo htmlspecialchars($row[$opt]); ?></span>
            </label>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
        </div>

        <div class="nav-container">
            <button type="button" id="prevBtn" class="nav-btn">PREVIOUS</button>
            <div id="pageIndicator" style="font-weight:bold; color:var(--primary-dark); letter-spacing:1px;">PAGE 1 / <?php echo $totalPages; ?></div>
            <button type="button" id="nextBtn" class="nav-btn">NEXT</button>
            <button type="submit" id="submitBtn" class="nav-btn" style="display:none;">FINISH & SUBMIT</button>
        </div>
    </form>
<?php endif; ?>

<script>
<?php if(!$already_taken): ?>
    const questions = document.querySelectorAll(".question");
    const dots = document.querySelectorAll(".dot");
    const prevBtn = document.getElementById("prevBtn");
    const nextBtn = document.getElementById("nextBtn");
    const submitBtn = document.getElementById("submitBtn");
    const pageIndicator = document.getElementById("pageIndicator");
    const timerBar = document.getElementById("timerBar");
    const topTimer = document.getElementById("top-timer-text");
    
    let currentPage = 0;
    const perPage = 2;
    const totalPages = <?php echo $totalPages; ?>;

    function showPage(page){
        questions.forEach((q,index)=>{
            q.style.display = (index >= page*perPage && index < (page+1)*perPage) ? "block" : "none";
        });
        dots.forEach((dot, i) => dot.classList.toggle("active", i === page));
        
        prevBtn.style.visibility = (page===0) ? "hidden" : "visible";
        nextBtn.style.display = (page+1 >= totalPages) ? "none" : "block";
        submitBtn.style.display = (page+1 >= totalPages) ? "block" : "none";
        pageIndicator.textContent = "PAGE " + (page+1) + " / " + totalPages;
        window.scrollTo({top: 0, behavior: 'smooth'});
    }

    document.getElementById("realStartBtn").addEventListener('click', () => {
        let elem = document.documentElement;
        if (elem.requestFullscreen) elem.requestFullscreen();
        document.getElementById("startOverlay").style.display = 'none';
        startTimer();
        showPage(0);
    });

    document.addEventListener("fullscreenchange", () => {
        if (!document.fullscreenElement) {
            alert("Security Breach: Auto-submitting...");
            document.getElementById("examForm").submit();
        }
    });

    function startTimer() {
        const totalMinutes = <?php
            $exam_info = $conn->query("SELECT time_minutes FROM exams WHERE id='$exam'");
            $row = $exam_info->fetch_assoc();
            echo ($row['time_minutes'] ?? 0);
        ?>;
        let totalSeconds = totalMinutes * 60;
        let remaining = totalSeconds;
        
        const interval = setInterval(() => {
            let m = Math.floor(remaining / 60);
            let s = remaining % 60;
            topTimer.innerHTML = `<i class="far fa-clock"></i> ${m}:${s < 10 ? '0' : ''}${s}`;
            
            // የቀረው ሰዓት በመቶኛ (Percentage)
            let per = (remaining / totalSeconds) * 100;
            timerBar.style.width = per + "%";
            
            // ሰዓቱ ሲያልቅ ቀለሙን ወደ ጥቁር ቀይ መቀየር
            if(per < 20) timerBar.style.background = "#7f1d1d";

            if(remaining <= 0){
                clearInterval(interval);
                document.getElementById('examForm').submit();
            }
            remaining--;
        }, 1000);
    }

    nextBtn.addEventListener("click", ()=>{ if(currentPage < totalPages-1){ currentPage++; showPage(currentPage); } });
    prevBtn.addEventListener("click", ()=>{ if(currentPage > 0){ currentPage--; showPage(currentPage); } });
<?php endif; ?>
</script>
</body>
</html>