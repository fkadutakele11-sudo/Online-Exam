<?php
include "db.php";
?>
<!DOCTYPE html>
<html>
<head>

<title>Manage Users</title>

<style>

/* ===== PAGE ===== */
body{
margin:0;
font-family:Arial, Helvetica, sans-serif;
background:#f4f6f9;
}

/* ===== NAVBAR ===== */
.navbar{
background:#1f6690;
}

.navbar ul{
margin:0;
padding:0;
list-style:none;
display:flex;
justify-content:center;
}

.navbar li{
padding:16px 25px;
}

.navbar a{
color:white;
text-decoration:none;
font-weight:bold;
}

.navbar a:hover{
color:#6dd5fa;
}

/* ===== HEADER ===== */
.header{
background:#2980b9;
color:white;
padding:18px;
display:flex;
justify-content:space-between;
align-items:center;
}

/* ===== CONTAINER ===== */
.container{
max-width:950px;
margin:40px auto;
}

/* ===== MESSAGE ===== */
.message{
background:#d4edda;
color:#155724;
padding:12px;
border-radius:6px;
margin-bottom:15px;
font-weight:bold;
}

/* ===== BUTTONS ===== */
.actions{
margin-bottom:15px;
}

.btn{
padding:9px 18px;
border:none;
border-radius:5px;
cursor:pointer;
color:white;
margin-right:10px;
}

.edit{ background:#27ae60; }
.delete{ background:#e74c3c; }
.back{ background:#7f8c8d; }

.btn:hover{ opacity:0.85; }

/* ===== TABLE ===== */
table{
width:100%;
border-collapse:collapse;
background:white;
box-shadow:0 6px 18px rgba(0,0,0,0.12);
}

table th, table td{
padding:13px;
border-bottom:1px solid #ddd;
text-align:center;
}

table th{
background:#2980b9;
color:white;
}

tr:hover{
background:#ecf0f1;
cursor:pointer;
}

.selected{
background:#d6eaf8 !important;
}

</style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
<ul>
<li><a href="admin.php">Dashboard</a></li>
<li><a href="manage_users.php">Manage Users</a></li>
<li><a href="logout.php">Logout</a></li>
</ul>
</div>

<!-- HEADER -->
<div class="header">
<h2>Manage Users</h2>

<a href="admin.php">
<button class="btn back">Back</button>
</a>
</div>

<div class="container">

<?php
/* SUCCESS MESSAGE */
if(isset($_GET['msg'])){
echo "<div class='message'>".$_GET['msg']."</div>";
}
?>

<!-- ACTION BUTTONS -->
<div class="actions">
<button class="btn edit" onclick="editUser()">Edit</button>
<button class="btn delete" onclick="deleteUser()">Delete</button>
</div>

<input type="hidden" id="selectedUser">

<table id="userTable">

<tr>
<th>ID</th>
<th>Name</th>
<th>Student ID</th>
<th>Role</th>
</tr>

<?php
$result=$conn->query("SELECT * FROM users");

while($row=$result->fetch_assoc()){

echo "<tr onclick='selectUser(this,".$row['id'].")'>";
echo "<td>".$row['id']."</td>";
echo "<td>".$row['name']."</td>";
echo "<td>".$row['student_id']."</td>";
echo "<td>".$row['role']."</td>";
echo "</tr>";
}
?>

</table>

</div>

<script>

/* SELECT ROW */
function selectUser(row,id){

let rows=document.querySelectorAll("#userTable tr");

rows.forEach(r=>r.classList.remove("selected"));

row.classList.add("selected");

document.getElementById("selectedUser").value=id;
}

/* EDIT USER */
function editUser(){

let id=document.getElementById("selectedUser").value;

if(id==""){
alert("Select a user first");
return;
}

/* ✅ FIXED FILE NAME */
window.location="edit_user.php?id="+id;
}

/* DELETE USER */
function deleteUser(){

let id=document.getElementById("selectedUser").value;

if(id==""){
alert("Select a user first");
return;
}

if(confirm("Delete this user?")){
window.location="delete_user.php?id="+id;
}
}

</script>

</body>
</html>