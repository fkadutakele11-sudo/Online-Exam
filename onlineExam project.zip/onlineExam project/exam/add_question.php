<?php
include "db.php";
session_start();

// መልዕክቱን ከሴሽን ለመቀበል
$message = "";
if (isset($_SESSION['msg'])) {
    $message = $_SESSION['msg'];
    unset($_SESSION['msg']); 
}

$active_tab = isset($_SESSION['active_tab']) ? $_SESSION['active_tab'] : 'manual';
unset($_SESSION['active_tab']); 

// --- manual questions ---
if(isset($_POST['add_manual'])){
    $conn->query("INSERT INTO questions (exam_id,question,A,B,C,D,correct) VALUES('".$_POST['exam_id']."','".$_POST['question']."','".$_POST['A']."','".$_POST['B']."','".$_POST['C']."','".$_POST['D']."','".$_POST['correct']."')");
    
    $_SESSION['msg'] = "<p class='message'>✔ Question Added Successfully!</p>";
    $_SESSION['active_tab'] = 'manual';
    header("Location: " . $_SERVER['PHP_SELF']); 
    exit();
}

// file upload ---
if(isset($_POST['upload_file'])){
    $exam_id = $_POST['exam_id_file'];

    if(isset($_FILES['question_file']) && $_FILES['question_file']['error'] == 0){
        $tmp = $_FILES['question_file']['tmp_name'];
        $lines = file($tmp, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $q = $A = $B = $C = $D = $correct = ""; 
        $count = 0;

        foreach($lines as $line){
            $line = trim($line);
            if(stripos($line,"Answer:")===0){
                $correct = trim(substr($line,7));
                if($q && $A && $B && $C && $D && $correct){
                    $conn->query("INSERT INTO questions (exam_id,question,A,B,C,D,correct) VALUES('$exam_id','$q','$A','$B','$C','$D','$correct')");
                    $count++;
                }
                $q = $A = $B = $C = $D = $correct = "";
            } elseif(stripos($line,"A.")===0){ $A = trim(substr($line,2));
            } elseif(stripos($line,"B.")===0){ $B = trim(substr($line,2));
            } elseif(stripos($line,"C.")===0){ $C = trim(substr($line,2));
            } elseif(stripos($line,"D.")===0){ $D = trim(substr($line,2));
            } elseif(preg_match("/^\d+\./",$line)){ $q = trim(preg_replace("/^\d+\./","",$line)); }
        }
        
        $_SESSION['msg'] = "<p class='message'>📊 $count Questions Uploaded Successfully.</p>";
        $_SESSION['active_tab'] = 'upload';
        header("Location: " . $_SERVER['PHP_SELF']); 
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Question | Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root { --primary: #2c3e50; --accent: #3498db; --success: #27ae60; --bg: #f4f7f6; }
        body { font-family: 'Inter', sans-serif; background: var(--bg); display: flex; flex-direction: column; align-items: center; padding: 20px; }
        
        /* Go Back Button Style */
        .top-nav { width: 100%; max-width: 600px; display: flex; justify-content: flex-start; margin-bottom: 15px; }
        .back-btn { 
            text-decoration: none; background: #fff; color: var(--primary); 
            padding: 10px 18px; border-radius: 10px; font-weight: 600; font-size: 14px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05); transition: 0.3s; display: flex; align-items: center; gap: 8px;
        }
        .back-btn:hover { background: var(--primary); color: white; transform: translateX(-5px); }

        .nav-container { display: flex; gap: 10px; margin-bottom: 25px; background: #e0e6ed; padding: 5px; border-radius: 12px; width: 100%; max-width: 600px; }
        .nav-tab { flex: 1; padding: 12px; text-align: center; cursor: pointer; border-radius: 8px; font-weight: 600; color: #555; transition: 0.3s; }
        .nav-tab.active { background: white; color: var(--accent); box-shadow: 0 4px 10px rgba(0,0,0,0.05); }

        .form-section { display: none; width: 100%; max-width: 600px; }
        .form-section.active { display: block; animation: fadeIn 0.4s ease; }
        
        .card { background: white; padding: 30px; border-radius: 16px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); border: 1px solid #eee; }
        h2 { color: var(--primary); text-align: center; margin-top: 0; margin-bottom: 20px; font-size: 18px; text-transform: uppercase; letter-spacing: 1px; }
        
        input, select { width: 100%; padding: 12px; margin-bottom: 15px; border: 2px solid #edf2f7; border-radius: 10px; box-sizing: border-box; font-size: 14px; }
        .options-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        
        button { width: 100%; padding: 14px; background: var(--accent); color: white; border: none; border-radius: 10px; font-weight: 600; cursor: pointer; margin-top: 10px; font-size: 15px; }
        button:hover { background: #2980b9; }

        .message { background: #e8f5e9; color: var(--success); padding: 15px; border-radius: 10px; text-align: center; border-left: 5px solid var(--success); margin-top: 20px; font-weight: 600; }
        
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body>

<div class="top-nav">
    <a href="instructor.php" class="back-btn">⬅ Go Back to Dashboard</a>
</div>

<div class="nav-container">
    <div id="tab-manual" class="nav-tab <?php echo ($active_tab == 'manual') ? 'active' : ''; ?>" onclick="showForm('manual')">✍️ Manual Entry</div>
    <div id="tab-upload" class="nav-tab <?php echo ($active_tab == 'upload') ? 'active' : ''; ?>" onclick="showForm('upload')">📁 Bulk Upload</div>
</div>

<div id="manual-section" class="form-section <?php echo ($active_tab == 'manual') ? 'active' : ''; ?>">
    <div class="card">
        <h2>Add Question Manually</h2>
        <form method="POST">
            <select name="exam_id" required>
                <?php
                $e=$conn->query("SELECT * FROM exams");
                while($row=$e->fetch_assoc()){ echo "<option value='".$row['id']."'>Exam ".$row['id']."</option>"; }
                ?>
            </select>
            <input type="text" name="question" placeholder="Enter Question Description" required>
            <div class="options-grid">
                <input type="text" name="A" placeholder="Option A" required>
                <input type="text" name="B" placeholder="Option B" required>
                <input type="text" name="C" placeholder="Option C" required>
                <input type="text" name="D" placeholder="Option D" required>
            </div>
            <select name="correct" required>
                <option value="" disabled selected>Select Correct Answer</option>
                <option>A</option><option>B</option><option>C</option><option>D</option>
            </select>
            <button name="add_manual">Save Question</button>
        </form>
        <?php if($active_tab == 'manual') echo $message; ?>
    </div>
</div>

<div id="upload-section" class="form-section <?php echo ($active_tab == 'upload') ? 'active' : ''; ?>">
    <div class="card">
        <h2>Bulk Upload (TXT File)</h2>
        <form method="POST" enctype="multipart/form-data">
            <select name="exam_id_file" required>
                <?php
                $e=$conn->query("SELECT * FROM exams");
                while($row=$e->fetch_assoc()){ echo "<option value='".$row['id']."'>Exam ".$row['id']."</option>"; }
                ?>
            </select>
            <input type="file" name="question_file" accept=".txt" required>
            <button name="upload_file">Start Bulk Upload</button>
        </form>
        <?php if($active_tab == 'upload') echo $message; ?>
    </div>
</div>

<script>
function showForm(type) {
    document.querySelectorAll('.form-section').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.nav-tab').forEach(el => el.classList.remove('active'));

    if(type === 'manual') {
        document.getElementById('manual-section').classList.add('active');
        document.getElementById('tab-manual').classList.add('active');
    } else {
        document.getElementById('upload-section').classList.add('active');
        document.getElementById('tab-upload').classList.add('active');
    }
}
</script>

</body>
</html>