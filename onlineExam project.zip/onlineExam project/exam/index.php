<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DTU | Online Examination System</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary: #4f46e5;
            --secondary: #0ea5e9;
            --accent: #6dd5fa;
        }

        body {
            margin: 0;
            font-family: 'Plus Jakarta Sans', sans-serif;
            /* Your background image remains the hero here */
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.7)), url('Web1.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            height: 100vh;
            color: white;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        /* Professional Navbar */
        .navbar {
            background: rgba(15, 23, 42, 0.85);
            backdrop-filter: blur(15px);
            padding: 0 5%;
            height: 80px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            box-sizing: border-box;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logo {
            font-size: 30px;
            font-weight: 800;
            letter-spacing: -1px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 30px;
            align-items: center;
        }

        .nav-links a {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
            cursor: pointer;
            text-transform: uppercase;
        }

        .nav-links a:hover {
            color: var(--accent);
        }

        .btn-login {
            background: var(--primary);
            padding: 12px 28px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(79, 70, 229, 0.4);
            color: white !important;
        }

        /* Main Viewport */
        .viewport {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding-top: 80px;
        }

        /* The Main Container that holds sections */
        .content-card {
            background:GREEN;/* Light glass effect for the main card */
            backdrop-filter: blur(10px);
            padding: 50px;
            border-radius: 30px;
            width: 90%;
            max-width: 900px;
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* MARQUEE WITHOUT BOX - FLOATING TEXT */
        .marquee-wrapper {
            width: 100%;
            overflow: hidden;
            background: transparent; /* Box Removed */
            backdrop-filter: none;    /* Blur Removed */
            border: none;             /* Border Removed */
            padding: 10px 0;
            margin-bottom: 20px;
            cursor: pointer;
        }

        .marquee-text {
            display: inline-block;
            font-size: 42px;
            font-weight: 900;
            text-transform: uppercase;
            white-space: nowrap;
            animation: marquee 18s linear infinite;
            color: white;
            /* Strong shadow to make text pop against the background image */
            text-shadow: 2px 4px 10px rgba(0, 0, 0, 0.8);
        }

        .marquee-wrapper:hover .marquee-text {
            animation-play-state: paused;
            color: var(--accent);
        }

        @keyframes marquee {
            0% { transform: translateX(100%); }
            100% { transform: translateX(-100%); }
        }

        /* Section Visibility Logic */
        .section { display: none; animation: fadeIn 0.5s ease-in-out; }
        .section.active { display: block; }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h2 { font-size: 30px; margin-bottom: 15px; text-shadow: 1px 1px 5px rgba(0,0,0,0.5); }
        p { color: #e2e8f0; line-height: 1.7; font-size: 17px; }

        .contact-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 25px;
        }

        .contact-item {
            background: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 15px;
        }
        .contact-item i { color: var(--accent); font-size: 20px; margin-bottom: 8px; }
    </style>
</head>
<body>

<nav class="navbar">
    <div class="logo">
        <i class="fas fa-university"></i> DTU ONLINE EXAM
    </div>
    <ul class="nav-links">
        <li><a onclick="showSection('home')">Home</a></li>
        <li><a onclick="showSection('about')">About</a></li>
        <li><a onclick="showSection('contact')">Contact</a></li>
        <li><a href="login.php" class="btn-login">Sign In</a></li>
    </ul>
</nav>

<div class="viewport">
    <div class="content-card">
        
        <div id="home" class="section active">
            <div class="marquee-wrapper">
                <div class="marquee-text">
                    Welcome to Debre Tabor University Online Examination System
                </div>
            </div>
            <h2>Academic Excellence Portal</h2>
            <p>Empowering the future through digital innovation. Our secure platform provides a seamless testing experience for students and instructors alike.</p>
        </div>

        <div id="about" class="section">
            <i class="fas fa-graduation-cap" style="font-size: 40px; color: var(--accent); margin-bottom: 15px;"></i>
            <h2>System Overview</h2>
            <p>Our Online Examination System is built to ensure academic integrity and efficiency. Developed for Debre Tabor University, it automates grading, provides instant results, and simplifies exam management.</p>
        </div>

        <div id="contact" class="section">
            <h2>Support Center</h2>
            <p>Contact the technical team for portal assistance.</p>
            <div class="contact-grid">
                <div class="contact-item">
                    <i class="fas fa-phone"></i>
                    <div>+251 939 59 71 91</div>
                </div>
                <div class="contact-item">
                    <i class="fas fa-envelope"></i>
                    <div>support@dtu.edu.et</div>
                </div>
                <div class="contact-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <div>Debre Tabor, Amhara</div>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
    function showSection(id) {
        // Hide all sections
        document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
        // Activate the clicked section
        document.getElementById(id).classList.add('active');
    }
</script>

</body>
</html>