<?php
include "db.php";

// ===== Determine department column automatically =====
$deptColumn = null;
$result = $conn->query("SHOW COLUMNS FROM courses");
while($row = $result->fetch_assoc()){
    if(strpos(strtolower($row['Field']), 'dept') !== false || strpos(strtolower($row['Field']), 'department') !== false){
        $deptColumn = $row['Field'];
        break;
    }
}

$hasDept = $deptColumn !== null;

// ===== Function to render course table =====
function renderCourseTable($conn, $hasDept, $deptColumn){
    if($hasDept){
        $c = $conn->query("
            SELECT courses.id, courses.course_name, departments.dept_name 
            FROM courses 
            LEFT JOIN departments ON courses.$deptColumn = departments.id
            ORDER BY courses.id ASC
        ");
    } else {
        $c = $conn->query("SELECT id, course_name FROM courses ORDER BY id ASC");
    }

    echo '<table class="prof-table">';
    echo $hasDept 
        ? '<tr><th>ID</th><th>Course</th><th>Department</th><th>Action</th></tr>'
        : '<tr><th>ID</th><th>Course</th><th>Action</th></tr>';

    while($row = $c->fetch_assoc()){
        echo '<tr>';
        echo '<td>'.$row['id'].'</td>';
        echo '<td>'.$row['course_name'].'</td>';
        if($hasDept) echo '<td>'.$row['dept_name'].'</td>';
        echo '<td><button class="delete-btn" data-id="'.$row['id'].'">Delete</button></td>';
        echo '</tr>';
    }
    echo '</table>';
}

// ===== Handle AJAX Add Course =====
if(isset($_POST['action']) && $_POST['action'] === 'add'){
    $course = $_POST['course'];
    $dept_id = $hasDept ? $_POST['dept_id'] : null;

    if($hasDept){
        $stmt = $conn->prepare("INSERT INTO courses(course_name, $deptColumn) VALUES(?, ?)");
        $stmt->bind_param("si", $course, $dept_id);
        $stmt->execute();
    } else {
        $stmt = $conn->prepare("INSERT INTO courses(course_name) VALUES(?)");
        $stmt->bind_param("s", $course);
        $stmt->execute();
    }

    renderCourseTable($conn, $hasDept, $deptColumn);
    exit;
}

// ===== Handle AJAX Delete Course =====
if(isset($_POST['action']) && $_POST['action'] === 'delete'){
    $id = $_POST['id'];
    $conn->query("DELETE FROM courses WHERE id='$id'");
    renderCourseTable($conn, $hasDept, $deptColumn);
    exit;
}

// ===== Default Page Load =====
?>
<div class="card">
    <h3>Add New Course</h3>
    <form id="addCourseForm">
        Course Name<br>
        <input type="text" name="course" required>
        <?php if($hasDept): ?>
            Department<br>
            <select name="dept_id">
                <?php
                $d = $conn->query("SELECT * FROM departments");
                while($row = $d->fetch_assoc()){
                    echo "<option value='".$row['id']."'>".$row['dept_name']."</option>";
                }
                ?>
            </select>
        <?php endif; ?>
        <button type="submit">Add Course</button>
    </form>
</div>

<div class="card">
    <h3>Existing Courses</h3>
    <div id="courseTable">
        <?php renderCourseTable($conn, $hasDept, $deptColumn); ?>
    </div>
</div>

<script>
// ===== Event delegation for Delete (works dynamically) =====
document.getElementById('courseTable').addEventListener('click', function(e){
    if(e.target && e.target.classList.contains('delete-btn')){
        if(confirm('Are you sure you want to delete this course?')){
            let id = e.target.getAttribute('data-id');
            let formData = new FormData();
            formData.append('action','delete');
            formData.append('id', id);
            fetch('manage_courses.php', {
                method:'POST',
                body: formData
            })
            .then(res => res.text())
            .then(html => {
                document.getElementById('courseTable').innerHTML = html;
            });
        }
    }
});

// ===== Add Course via AJAX =====
document.getElementById('addCourseForm').addEventListener('submit', function(e){
    e.preventDefault();
    let formData = new FormData(this);
    formData.append('action','add');
    fetch('manage_courses.php', {
        method:'POST',
        body: formData
    })
    .then(res => res.text())
    .then(html => {
        document.getElementById('courseTable').innerHTML = html;
        this.reset();
    });
});
</script>