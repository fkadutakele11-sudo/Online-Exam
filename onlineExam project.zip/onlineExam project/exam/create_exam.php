<?php
include "db.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Exam | Instructor Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #1e293b;
            --accent: #3b82f6;
            --success: #10b981;
            --bg: #f8fafc;
            --white: #ffffff;
            --border: #e2e8f0;
        }

        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background: var(--bg);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            width: 100%;
            max-width: 550px;
            animation: fadeIn 0.4s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Top Back Button */
        .top-nav {
            margin-bottom: 20px;
        }

        .btn-back {
            text-decoration: none;
            color: #64748b;
            font-size: 14px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: 0.2s;
        }

        .btn-back:hover {
            color: var(--accent);
        }

        .card {
            background: var(--white);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.05);
            border: 1px solid var(--border);
        }

        h2 {
            margin: 0 0 25px 0;
            color: var(--primary);
            font-size: 24px;
            font-weight: 700;
            text-align: center;
        }

        .form-group { margin-bottom: 20px; }

        label {
            display: block;
            font-weight: 600;
            color: #475569;
            margin-bottom: 8px;
            font-size: 14px;
        }

        select, input {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--border);
            border-radius: 12px;
            font-size: 15px;
            color: var(--primary);
            box-sizing: border-box;
            transition: 0.2s;
        }

        input:focus, select:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
        }

        .date-grid {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr;
            gap: 10px;
        }

        .two-col {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .btn-create {
            width: 100%;
            padding: 15px;
            background: var(--accent);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 10px;
        }

        .btn-create:hover {
            background: #2563eb;
            transform: translateY(-1px);
        }

        .message {
            margin-top: 20px;
            padding: 15px;
            border-radius: 12px;
            text-align: center;
            font-weight: 600;
            background: #ecfdf5;
            color: var(--success);
            border: 1px solid #d1fae5;
        }

        .msg-footer {
            margin-top: 10px;
            font-size: 13px;
            color: #065f46;
            display: block;
            font-weight: 400;
        }

        /* Dashboard Link inside message */
        .dash-link {
            display: inline-block;
            margin-top: 15px;
            background: var(--success);
            color: white;
            padding: 8px 15px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 14px;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="top-nav">
        <a href="instructor.php" class="btn-back">⬅ Back to Dashboard</a>
    </div>

    <div class="card">
        <h2>Create New Exam</h2>

        <form method="POST">
            <div class="form-group">
                <label>Course</label>
                <select name="course_id" required>
                    <option value="" disabled selected>Select Course</option>
                    <?php
                    $c=$conn->query("SELECT * FROM courses");
                    while($row=$c->fetch_assoc()){
                        echo "<option value='".$row['id']."'>".$row['course_name']."</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label>Exam Type</label>
                <select name="type" required>
                    <option>Quiz</option>
                    <option>Test</option>
                    <option>Final</option>
                </select>
            </div>

            <div class="form-group">
                <label>Schedule Date (English Calendar)</label>
                <div class="date-grid">
                    <select name="month" required>
                        <option>January</option><option>February</option><option>March</option>
                        <option>April</option><option>May</option><option>June</option>
                        <option>July</option><option>August</option><option>September</option>
                        <option>October</option><option>November</option><option>December</option>
                    </select>
                    <select name="day" required>
                        <?php for($i=1; $i<=31; $i++) echo "<option value='$i'>$i</option>"; ?>
                    </select>
                    <select name="year" required>
                        <option>2026</option><option>2027</option>
                    </select>
                </div>
            </div>

            <div class="two-col">
                <div class="form-group">
                    <label>Duration (Min)</label>
                    <input type="number" name="time" placeholder="60" required>
                </div>
                <div class="form-group">
                    <label>Weight (%)</label>
                    <input type="number" name="percentage" placeholder="25" required>
                </div>
            </div>

            <button name="create" class="btn-create">Create Exam</button>
        </form>

        <?php
        if(isset($_POST['create'])){
            $type = $_POST['type'];
            $time = $_POST['time'];
            $percent = $_POST['percentage'];

            // DB logic (Unchanged)
            $conn->query("INSERT INTO exams(course_id,exam_type,time_minutes)
            VALUES(
                '".$_POST['course_id']."',
                '".$_POST['type']."',
                '".$_POST['time']."'
            )");

            echo "<div class='message'>
                    ✅ Exam Created Successfully!
                    <span class='msg-footer'>Type: <b>$type</b> | Time: <b>$time Min</b> | Weight: <b>$percent%</b></span>
                    <a href='instructor.php' class='dash-link'>Go to Dashboard</a>
                  </div>";
        }
        ?>
    </div>
</div>

</body>
</html>