<?php
session_start();
include "db.php";

// 1. ተማሪው መግባቱን ያረጋግጣል - ካልገባ ወደ login.php ይልካል
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

// የገባው ተማሪ ID
$student_id = $_SESSION['student_id'];
?>

<div class="card">
    <h3>My Exam Results</h3>
    <table class="prof-table">
        <tr>
            <th>Course</th>
            <th>Score</th>
            <th>Exam Date</th>
        </tr>

    <?php
    // 2. ተማሪው የራሱን ውጤት ብቻ እንዲያይ WHERE r.student_id ተጨምሯል
    // ማሳሰቢያ፡ በዳታቤዝህ ሰንጠረዥ 'student_id' የውጭ ቁልፍ (Foreign Key) መሆኑን እርግጠኛ ሁን
    $stmt = $conn->prepare("SELECT r.course, r.score, r.exam_date 
                           FROM studentResults r 
                           WHERE r.student_id = ?
                           ORDER BY r.exam_date DESC");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows > 0) {
        while($row = $res->fetch_assoc()){
            echo "<tr>
                <td>".$row['course']."</td>
                <td><strong>".$row['score']."</strong></td>
                <td>".$row['exam_date']."</td>
            </tr>";
        }
    } else {
        echo "<tr><td colspan='3' style='text-align:center;'>No results found.</td></tr>";
    }
    $stmt->close();
    ?>
    </table>
</div>